<?php  
include 'db2.php';

$bedrooms = $mysqli->escape_string($_POST['bedrooms']);
$city = $mysqli->escape_string($_POST['city']);
$price = $mysqli->escape_string($_POST['price']);
$type = $mysqli->escape_string($_POST['type']);
$title = $mysqli->escape_string($_POST['title']);
$booking = $mysqli->escape_string($_POST['booking']);
$rating = $mysqli->escape_string('0');
 
  $connect = mysqli_connect("localhost", "root","58f58c3095714c9c8def5a6896ef435460ef4286c7b9ef61", "accounts");  
 if(isset($_POST["insert"]))  
 {  
      $file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));  
      $query = "INSERT INTO listings(title,bedrooms,price,type,city,owner,pic,Booking,Email,Rating) VALUES ('$title','$bedrooms','$price','$type', '$city','$first_name','$file','$Booking', '$email', '$rating')";  
      if(mysqli_query($connect, $query))  
      {  
           echo '<script>alert("Image Inserted into Database")</script>';
           header("location: browse.php");  
      }  
 }
 if(isset($_POST["delete"])){
   $file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));  
      $query = "DELETE FROM listings WHERE owner = '$first_name'";  
      if(mysqli_query($connect, $query))  
      {  
           echo '<script>alert("Image deleted into Database")</script>';  
      }  
 }   
 ?>  

<head>
  <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" type="text/css" href="css/style.css">
        
      </head>
      <body>
        <body>
        <?php include 'stuff/navbar.php'; ?>
        
      <div id="body">
         
                <form method="post" enctype="multipart/form-data"> 
                <br><span style = "color: white">title</span></br>
                <input type='text' name='title' id='' placeholder='title' value=''/> 
                <br><span style = "color: white">city</span></br>
                <input type='text' name='city' id='city' placeholder='city' value=''/>
                <br><span style = "color: white">price</span></br>
                <input type='text' name='price' id='price' placeholder='price' value=''/> 
                <br><span style = "color: white">Type</span></br>
                <input type='text' name='type' id='type' placeholder='type' value=''/>
                <br><span style = "color: white">Bedrooms</span></br>
                <input type='text' name='bedrooms' id='bedrooms' placeholder='bedrroms' value='' />
                <br><span style = "color: white">Pic</span></br> 
                 <input type="file" name="image" id="image" />  
                  <br />  
                  <input type="submit" name="insert" id="insert" value="Insert" class="btn btn-info" />  
                   <!-- <input type="submit" name="delete" id="delete" value="Delete" class="btn btn-info" />  -->
              </form>
              </div>
              </body>
            <?php include 'stuff/footer.php'; ?>
    
 </html>  

 
