<?php
/* Log out process, unsets and destroys session variables */
session_start();
session_unset();
session_destroy(); 
?>
<!DOCTYPE html>
<head>
	<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<link rel="stylesheet" type="text/css" href="css/style.css">
				<script type="text/javascript" src="js/javascript.js"></script>
			</head>
			<body>
				<body>
					<?php include 'stuff/header.php'; ?>
					<?php include 'stuff/navbar.php'; ?>
          				<h1>Thanks for stopping by</h1>
              
          				<p><?= 'You have been logged out!'; ?></p>
          
          				<a href="index.php"><button class="button button-block"/>Home</button></a>
					<?php include 'stuff/footer.php'; ?>

    				</div>
			</body>
			</html>