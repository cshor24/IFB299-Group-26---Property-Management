<head>
	<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<link rel="stylesheet" type="text/css" href="css/style.css">
				<script type="text/javascript" src="js/javascript.js"></script>
			</head>
			<body>
				<?php include 'stuff/header.php'; ?>
				<?php include 'stuff/navbar.php'; ?>
				<?php include 'db2.php'; ?>
				<?php session_start();
					
				if ($_SERVER['REQUEST_METHOD'] == 'POST')
				{
   				 if (isset($_POST['login'])) { //user logging in

        			require 'logins.php';

    				}

    				elseif (isset($_POST['register'])) { //user registering

        			require 'register.php';

    				}
				}
				?>
				
          
				<div id="body">
				&nbsp
          			<form action="signup.php" method="post" autocomplete="off">
				<span style = "color: white"> First Name</span>
				<input type='text' name='firstname' id='firstname' placeholder='First Name' value='' required/>
				<br><span style = "color: white">Last Name</span></br>
				<input type='text' name='lastname' id='lastname' placeholder='Last Name' value='' required/>
				<br><span style = "color: white">Email Address</span></br>
				<input type='email' name='email' id='email' placeholder='E-Mail Address' value='' required/>
				<br><span style = "color: white">Password</span></br>
				<input type='password' name='password' id='password' placeholder='Password' required/>
         			<input type='submit' class='submit' name='register' value='SignUp'/>

          			
				</form>
				</div>
				<?php include 'stuff/footer.php'; ?>
			</body>
		</html>
