<?php 
include 'db2.php';
$mysqli2 = NEW mysqli("localhost", "root","58f58c3095714c9c8def5a6896ef435460ef4286c7b9ef61", "accounts");
session_start();
if ($_GET[''] = $_GET['Name']){
	$owner = $_GET['Name'];
	


}

$review = ($_POST['reviews']);



$messageB = "$review";
$messageE = "$email";




if($owner === 'test') {
	echo "works";
} else {
	echo $owner;
	echo 'test';
}
$sql = "UPDATE listings SET Booking = '$messageB' WHERE owner = '$owner'";
$sql2 = "UPDATE listings SET Email = '$messageE' WHERE owner = '$owner'";
            
 // Add user to the database
if ( $mysqli2->query($sql) ){ 

}else 
echo "error";

if ( $mysqli2->query($sql2) ){  

}else 
echo "error";



?>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<!-- <script type="text/javascript" src="js/javascript.js"></script> -->
	</head>
	<body>
		<?php include 'stuff/navbar.php'; ?>
		<?php include 'db.php'; ?>
		
		
		<div id="body">
		<br>
		<p id="title">Send a message</p>
		<form method ="POST">
		<input type="text" name="reviews"/>
		<input class= "submit" type="SUBMIT" name="review" value="submit"/>
		</form>
		
	
		<?php include 'stuff/footer.php'; ?>
	</body>
</html>