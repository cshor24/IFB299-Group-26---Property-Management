<?php  
include 'db2.php';

      $file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));  
      $query = "INSERT INTO listings(title,bedrooms,price,type,city,owner,pic,Booking,Email,Rating) VALUES ('$title','$bedrooms','$price','$type', '$city','$first_name','$file','$Booking', '$email', '$rating')";  
      if(mysqli_query($connect, $query))  
      {  
           echo '<script>alert("Image Inserted into Database")</script>';
           header("location: browse.php");  
      }  
?>

 
