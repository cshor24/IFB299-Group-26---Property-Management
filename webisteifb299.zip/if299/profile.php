

<head>
	<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<link rel="stylesheet" type="text/css" href="css/style.css">
				
			</head>
			<body>
				<body>
					<?php include 'stuff/header.php'; ?>
					<?php include 'stuff/navbar.php'; ?>
					<?php include 'db2.php'; ?>
					<div id="body">
					<br>
          

         			<h2><?php echo $first_name.' '.$last_name; ?></h2>
          			<p><?= $email ?></p>
          				

          			<?php
					$sql = "SELECT * FROM users WHERE first_name= '$first_name'";
					  $result = $mysqli->query($sql); //$result = mysqli_result object
       	
        				while($row = $result->fetch_assoc()){ 
            				
       	 				}
					
        				?>
          
          								
					<?php include 'stuff/footer.php'; ?>
				</body>
			</html>

 



 
