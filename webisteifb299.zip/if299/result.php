
	<?php

	include 'db2.php';

		if($_GET[''] = $_GET['Name']){
			$search = $_GET['Name'];
		
		}

		$resultSet = $mysqli->query("SELECT * from listings WHERE city = '$search'");
        if($resultSet->num_rows > 0){
            while($rows = $resultSet->fetch_assoc())
            {
      
            $title = $rows['title'];
			$bedrooms=  $rows['bedrooms'];
			$city=  $rows['city'];
			$price = $rows['price'];
			$type = $rows['type'];
			$owner =  $rows['owner'];
			$rating = $rows['rating'];
			$pic =  '<td>' . $rows['pic'] . '</td><br>';
			$output ='<img src="data:image/jpeg;base64,'.base64_encode( $rows['pic'] ).'"/>';

        }
    }


	?>

	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="css/star.css">
		


	</head>
	<body>
		
		<?php include 'stuff/navbar.php'; ?>
			<div id="body">
			<br>

			<?php echo "Title :$title<br>";?>
			<?php echo "Bedrooms : $bedrooms<br>";?>
			<?php echo "Price : $price<br>";?>
			<?php echo "Type : $type<br>";?>
			<?php echo "Rating : $rating<br>";?>
			<?php echo "Owner : $owner<br>";?>
			<?php echo "Pic : <br> $output";?>
			<br>
			
			
			<a href="book.php?Name=<?php echo $owner?>"><button>Make a Booking</button></a>


			

			
			<?php
					if($_SESSION['logged_in'] == true) { 
				
      				echo'
					<form class="starRatings"  method="post">
						<span><div style="width:' . round(max(0,min(1,(($value1)-4)))*20+0.49) . 'px;"><button type="submit" name="value" value=5></button></div></span
						><span><div style="width:' . round(max(0,min(1,(($value1)-3)))*20+0.49) . 'px;"><button type="submit" name="value" value=4></button></div></span
						><span><div style="width:' . round(max(0,min(1,(($value1)-2)))*20+0.49) . 'px;"><button type="submit" name="value" value=3></button></div></span
						><span><div style="width:' . round(max(0,min(1,(($value1)-1)))*20+0.49) . 'px;"><button type="submit" name="value" value=2></button></div></span
						><span><div style="width:' . round(max(0,min(1,(($value1))))*20+0.49)   . 'px;"><button type="submit" name="value" value=1></button></div></span>
					</form>';
				
  
					$value = $_POST['value'];
					
					
					$sql = "UPDATE listings SET rating = '$value' WHERE city = '$city'";
					if ( $mysqli->query($sql) ){ 
						

					}

				}
				





				

			?>

			

		<?php include 'stuff/footer.php'; ?>
		</div>
	</body>
</html>
