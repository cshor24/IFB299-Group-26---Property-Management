<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/navbar.css">

 <?php include 'db2.php'; ?>
 <?php include 'db.php'; ?>
<ul>
  <li><a href="index.php">HOME</a></li>
  <li><a href="search.php">SEARCH</a></li>
  <li><a href="contact.php">CONTACT</a></li>

  
   <?php
  if($_SESSION["logged_in"] !=1 ) { 
      echo '<li><a href="signup.php">SIGN UP</a></li>';
      echo '<li style="float:right"><a href="login.php">LOGIN</a></li>';
  }
  ?>
  
  <?php
  if($_SESSION['logged_in'] == true) { 
      echo '<li><a href="browse.php">YOUR LISTINGS</a></li>';
      echo '<li style="float:right"><a href="logout.php">LOGOUT</a></li>';
      echo '<li><a href="add.php">ADD</a></li>';
      echo '<li style="float:right"><a href="profile.php">'.$first_name.'</a></li>';
     
  }
  ?>

  </ul>

</body>
</html>