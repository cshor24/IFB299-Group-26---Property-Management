<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<link rel="stylesheet" type="text/css" href="css/footer.css">
	<link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
	<div id="footer">
		<div id="footer-icons">
			<i class="fa fa-facebook-square fa-3x" onclick="window.location.href='https://www.facebook.com/'" aria-hidden="true"></i>
			&nbsp
			<i class="fa fa-twitter-square fa-3x" onclick="window.location.href='https://www.twitter.com/'" aria-hidden="true"></i>
			&nbsp
			<i class="fa fa-instagram fa-3x"onclick="window.location.href='https://www.instagram.com/'" aria-hidden="true"></i>
		</div>
	</div>

	
</body>

