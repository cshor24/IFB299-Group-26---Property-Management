<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="css/style.css">
    </head>
    <body>
        <?php include 'stuff/header.php';?>
        <?php include 'stuff/navbar.php'; ?>
        <div id="body">
<?php

include 'db2.php';

if ($_GET[''] = $_GET['Name'])
{
    $search = $_GET['Name'];
    $resultSet = $mysqli->query("SELECT * FROM listings WHERE city LIKE '%$search%'");
        if($resultSet->num_rows > 0){
            while($rows = $resultSet->fetch_assoc())
            {
      


            echo '<td>' . $rows['city'] . '</td><br />';
            echo '<td><a href="result.php?Name=' . $rows['city'] . '">See More</a></td><br />';

        }
    }

}
?>

        <?php include 'stuff/footer.php';?>
   </body>
</html>
