<?php
/* Database connection settings */
$host = 'localhost';
$user = 'root';
$pass = '58f58c3095714c9c8def5a6896ef435460ef4286c7b9ef61';
$db = 'accounts';
$mysqli = new mysqli($host,$user,$pass,$db) or die($mysqli->error);


/* Displays user information and some useful messages */
session_start();

//Check if user is logged in using the session variable
if ( $_SESSION['logged_in'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  // header("location: error.php");    
}
else {
    // Makes it easier to read
    $first_name = $_SESSION['first_name'];
    $last_name = $_SESSION['last_name'];
    $email = $_SESSION['email'];
    $active = $_SESSION['active'];
    $pics = $_SESSION['pics'];
    $id = $_SESSION['id'];
}
?>
