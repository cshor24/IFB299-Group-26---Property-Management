
	<?php 
	$output = NULL;
		include 'db2.php';
		session_start();
		$connect = mysqli_connect("localhost", "root","58f58c3095714c9c8def5a6896ef435460ef4286c7b9ef61", "accounts");
		 if(isset($_POST["delete"])){
 	 		$file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));  
      		$query = "DELETE FROM listings WHERE owner = '$first_name'";  
      		if(mysqli_query($connect, $query))  
      		{  
           echo '<script>alert("Image deleted into Database")</script>';  
      		}  
 		} 


		$resultSet = $mysqli->query("SELECT * FROM listings WHERE owner = '$first_name'");
		if($resultSet->num_rows > 0){
			while($rows = $resultSet->fetch_assoc())
			{
				$city = $rows['city'];
				$title = $rows['title'];
				$tempowner = $rows['owner'];
				$sn[] = $city;
				$yn[] = $title;
				$owner[] = $tempowner;
				$output2[] = "city: $city<br /> title: $title<br /> owner: $tempowner<br /> ";
				$output[] ='<img src="data:image/jpeg;base64,'.base64_encode( $rows['pic'] ).'"/>';
				$booking[] = $rows['Booking'];	
			}

		}else{
			$output = "nothing to display";
		}



	

	?>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body>
		<?php include 'stuff/navbar.php'; ?>
		
		
		<div id="body">
		
			 
			<?php
			for($i = 0; $i < count($sn); $i++){
				echo"
				<section class = outerContainer>
					
					<div id = imageWindow class = innerContainerLeft>

						 $output[$i]
						
					</div>
					<div id = test style ='float:right; width:20%;'> <p>$yn[$i]</p><p> $output2[$i]</p></div>
					<div id = infoWindow class = innerContainerLeft>
						<p>  $booking[$i]</p>
					</div>
				</section>";
			}?>
					
			
			<form method="post" enctype="multipart/form-data"> 
				<input type="submit" name="delete" id="delete" value="Delete" class="btn btn-info" /> 
			</form>
		</div>
		<?php include 'stuff/footer.php'; ?>
	</body>
</html>
