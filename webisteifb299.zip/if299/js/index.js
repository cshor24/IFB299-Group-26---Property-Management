
var imageIndex = 0;
nextImg(imageIndex);

function nextImg(val){
	dispImg(imageIndex += val);
}

function dispImg(val){
	var i;
	var imgClass = document.getElementsByClassName("slider");
	if (val > imgClass.length-1){
		imageIndex = 0;
	}
	if (val < 0) {
		imageIndex = imgClass.length-1;
	}

	for (j = 0; j < imgClass.length; j++){
		imgClass[j].style.display = "none";
	}
	imgClass[imageIndex].style.display="block";
}


//pseudo code for property comparison
