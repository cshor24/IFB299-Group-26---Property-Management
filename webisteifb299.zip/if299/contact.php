<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<?php include 'stuff/navbar.php'; ?>
		<?php include 'db2.php'; /*was "db.php" but that doesn't exist*/?>	
	</head>
	<body>
		<div id = "body">
		<br>
			<?php echo ""; ?>
			<p>
			<?php echo "26 Dave St, Davetown, QLD, 4026"; ?>
			</p>
			<?php include 'stuff/footer.php'; ?>
		</div>
	</body>
</html>