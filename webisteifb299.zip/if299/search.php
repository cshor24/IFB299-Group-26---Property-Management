	<?php

	if(isset($_POST['Name'])){

			$search = $_POST['Name'];
			header("Location: results.php?Name=$search");

	}



	?>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<!-- <script type="text/javascript" src="js/javascript.js"></script> -->
	</head>
	<body>
		<?php include 'stuff/navbar.php'; ?>
		<?php include 'db.php'; ?>
		
		
		<div id="body">
		
			<br>
			<form id = "form1" method="POST">
			<h3>Search by Name</h3>
			<input type="text" name="Name"/>
			<input  class= "submit" type="SUBMIT" name="submit" value="Search" />
			</form>

			

			<!-- <input  type="submit" name="booking" value="Make a Booking" /> -->
			

			
		
			
		</div>
		<?php include 'stuff/footer.php'; ?>
	</body>
</html>
