<!DOCTYPE html>
<html>
<?php
/* Displays user information and some useful messages */
session_start();

// Check if user is logged in using the session variable
if ( $_SESSION['logged_in'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  // header("location: error.php");    
}
else {
    // Makes it easier to read
    $first_name = $_SESSION['first_name'];
    $last_name = $_SESSION['last_name'];
    $email = $_SESSION['email'];
    $active = $_SESSION['active'];
}
?>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>David's Rentals</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body>
		<?php include 'stuff/navbar.php'; ?>
		<?php include 'db2.php'; ?>

		<div id="body">
			<div id="homepage">
				<div id="sliderContainer">
					<button class="button" style="float:left;" onclick="nextImg(-1)">&#10094;</button>
					<button class="button" style="float:right;" onclick="nextImg(+1)">&#10095;</button>
					<img class="slider" src="images/house1.jpg">
					<img class="slider" src="images/house2.jpg">
					<img class="slider" src="images/house3.jpg">
					<img class="slider" src="images/house4.jpg">
				</div>
			</div>	
			<script src = "js/index.js"></script>
			<title>VISIT COUNTER</title>

					<SCRIPT>
					expireDate = new Date
					expireDate.setMonth(expireDate.getMonth()+6)
					jcount = eval(cookieVal("jaafarCounter"))
					jcount++
					document.cookie = "jaafarCounter="+jcount+";expires=" + expireDate.toGMTString()

					function cookieVal(cookieName) {
					thisCookie = document.cookie.split("; ")
					for (i=0; i<thisCookie.length; i++){
					if (cookieName == thisCookie[i].split("=")[0]){
					return thisCookie[i].split("=")[1]
					}
					}
					return 0
					}

					function page_counter(){
					for (i=0;i<(7-jcount.toString().length);i++)
					document.write('<span class="counter">0</span>')
					for (y=0;y<(jcount.toString().length);y++)
					document.write('<span class="counter">'+jcount.toString().charAt(y)+'</span>')
					}
					</SCRIPT>

					<SCRIPT>
					page_counter(jcount);
					</SCRIPT>

		</div>						
	<?php include 'stuff/footer.php'; ?>
	</body>
</html>

<html>
<head>
