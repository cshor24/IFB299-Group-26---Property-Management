


<head>
	<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<link rel="stylesheet" type="text/css" href="css/style.css">
				<script type="text/javascript" src="js/javascript.js"></script>
			</head>
			<body>
				<body>
					<?php include 'stuff/header.php'; ?>
					<?php include 'stuff/navbar.php'; ?>
					<?php include 'db2.php'; ?>
					<?php session_start();
					
					if ($_SERVER['REQUEST_METHOD'] == 'POST')
					{
   					 if (isset($_POST['login'])) { //user logging in

        				require 'logins.php';

    					}

    					elseif (isset($_POST['register'])) { //user registering

        				require 'register.php';

    					}
					}
					?>
					<div id="body">
					&nbsp
					<p id="title">Log In</p>
					<form id='signin' action='login.php' method='post'>
					<span style = "color: white">Username</span>
					<input type='text' name='email' id='email' placeholder='email' value='' required/>
					<span style = "color: white">Password</span>
					<input type='password' name='password' id='password' placeholder='Password' value='' required/>
       					
					<input type='submit' class='submit' name='login' value='Log In'/>
					
					</div>
	
					<?php include 'stuff/footer.php'; ?>
				</body>
			</html>
